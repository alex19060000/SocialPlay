*******************************************************************
Asignatura: Tecnologías Emergentes (EI1053)
Titulación: Ingeniería Informática
Alumnos: (i) Francisco Montalt León; (ii) Alejandro Ferrari Alloza
Entrega: PRÁCTICA 2 
*******************************************************************

Datos del Proyecto:

"URL Endpoint": https://data.mongodb-api.com/app/data-aswmm/endpoint/data/beta
"API Key":    35T8wi898bvMLLXGqpwXu8ylF78f4XJKWLKSVfhlxbIIlt6RFfS1RK2dv42r39G6 
"Application ID": socialplay-spkot 
"dataSource": "Cluster0"
"database": "SocialPlayDB"
"collection": "Reserva"

******************************************************************************


## Install the project packages

npm install

## Create or reset the Database (model)

node model.js --create

## Check the Database with a simple query

node model.js

## Run de server

npm start

## Check the API in the browser

http://localhost:9000/graphql

## START your PROJECT!!
