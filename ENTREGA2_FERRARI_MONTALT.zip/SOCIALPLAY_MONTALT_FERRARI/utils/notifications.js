const SSE    = require('express-sse') //Server-side events
const events = require('events')

const STREAM = new SSE()

const emitter = new events.EventEmitter()

exports.eventStream = (req, res) => {
  console.log('Nueva conexion SSE ...')
  STREAM.init(req, res)
}

exports.start = () => {

    emitter.on('nueva-reserva', data => {
		 console.log("se ha creado una reserva!")

		  console.log(data)
          STREAM.send(JSON.stringify(data), 'nueva-reserva')
    })
	
	emitter.on('borrar-reserva', data => {
		console.log("se ha borrado una reserva!")

		  console.log(data)
          STREAM.send(JSON.stringify(data), 'borrar-reserva')
    })
	
	emitter.on('modificar-reserva', data => {
		  console.log("se ha modificado una reserva!")
		  console.log(data)
          STREAM.send(JSON.stringify(data), 'modificar-reserva')
    })


}

exports.emitter = emitter
exports.STREAM  = STREAM
