const Realm = require('realm')
const ObjectId = require('bson-objectid')
const myPartitionKey = "myAppPartition" 

const app = new Realm.App({ id: "socialplay-spkot" })

let UsuarioSchema = {
  name: 'Usuario',
  primaryKey: '_id',
  properties: {
    _id: 'objectId',
    nombre: 'string',
    apellidos: 'string',
    fecha_creacion: 'string',
    dni: 'string',
    avatar: 'string',
    email: 'string',
    pass: 'string',
	_partition: 'string'
  }
}
let ReservaSchema = {
  name: 'Reserva',
  primaryKey: '_id',

  properties: {
     _id: 'objectId',
    id_usuario: 'objectId',
    id_infraestructura: 'objectId',
    estado: 'string',
    fecha: 'string',
    hora_ini: 'string',
    hora_fin: 'string',
    num_personas: 'int',
	_partition: 'string'
  }
}
let InfraestructuraSchema = {
  name: 'Infraestructura',
  primaryKey: '_id',

  properties: {
    _id: 'objectId',
    nombre: 'string',
    ubicacion: 'string',
    area_metros: 'int',
    aforo_maximo: 'int',
    actividad: 'string',
	_partition: 'string'


  }
}


let DisponibilidadSchema = {
  name: 'Disponibilidad',
  primaryKey: '_id',

  properties: {
    _id: 'objectId',
    id_infraestructura: 'objectId',
    fecha_ini: 'string',
    fecha_fin: 'string',
    estacion: 'string',
    hora_ini: 'string',
    hora_fin: 'string',
	_partition: 'string'


  }
}

// // // MODULE EXPORTS
let sync = { user: app.currentUser, partitionValue: myPartitionKey}
let config = { path: './data/spfm.realm', sync: sync, schema: [UsuarioSchema, ReservaSchema, DisponibilidadSchema, InfraestructuraSchema] }


exports.getDB = async () => {
	await app.logIn(new Realm.Credentials.anonymous())
    return await Realm.open(config)

}

 exports.partitionKey = myPartitionKey
 exports.app = app


// // // // // 

if (process.argv[1] == __filename) {  //TESTING SEGMENT

  if (process.argv.includes("--create")) {  //crear la BD

    Realm.deleteFile({ path: './data/spfm.realm' }) //borramos base de datos si existe
	
	app.logIn(new Realm.Credentials.anonymous()).then(() => {

    let DB = new Realm({
      path: './data/spfm.realm',
	  sync: sync,
      schema: [UsuarioSchema, ReservaSchema, DisponibilidadSchema, InfraestructuraSchema]
    })

    DB.write(() => {
      let user = DB.create('Usuario', { _id: ObjectId(), nombre: 'Alex', apellidos: 'Ferrari Alloza', fecha_creacion: '02/28/2021', dni: '2', 
    avatar: 'www.google.es/images/ilma', email: 'al386114@uji.es', pass: 'hola', _partition: myPartitionKey   })


    let infraestructura1 = DB.create('Infraestructura', { _id:  ObjectId(), nombre: 'Pista de Tenis A1 de la UJI', ubicacion: 'Plaza 1 UJI', area_metros: 12, aforo_maximo: 5, actividad: 'Tenis', _partition: myPartitionKey  })
    let infraestructura2 = DB.create('Infraestructura', { _id:  ObjectId(), nombre: 'Pista de Tenis A2 de la UJI', ubicacion: 'Plaza 1 UJI', area_metros: 12, aforo_maximo: 5, actividad: 'Tenis', _partition: myPartitionKey  })
	let infraestructura3 = DB.create('Infraestructura', { _id:  ObjectId(), nombre: 'Cancha de Baloncesto de la UJI', ubicacion: 'Plaza 2 UJI', area_metros: 62, aforo_maximo: 11, actividad: 'Baloncesto', _partition: myPartitionKey  })

    let disp_inf1 = DB.create('Disponibilidad', {_id:  ObjectId(),  id_infraestructura: infraestructura1._id, fecha_ini:"3/7/2022", fecha_fin: "3/21/2022", 
    hora_ini:"9:00", hora_fin:"19:00", estacion:"Verano", _partition: myPartitionKey })

    let disp_inf2 = DB.create('Disponibilidad', {_id:  ObjectId(),  id_infraestructura: infraestructura2._id, fecha_ini:"3/7/2022", fecha_fin: "3/21/2022", 
    hora_ini:"10:00", hora_fin:"22:00", estacion:"Verano", _partition: myPartitionKey  })
	
	let disp_inf3 = DB.create('Disponibilidad', {_id:  ObjectId(),  id_infraestructura: infraestructura3._id, fecha_ini:"3/7/2022", fecha_fin: "3/21/2022", 
    hora_ini:"7:00", hora_fin:"00:00", estacion:"Verano", _partition: myPartitionKey  })

    

      console.log('Inserted objects', user, infraestructura1, infraestructura2, disp_inf1, disp_inf2)
    })
    DB.close()
	})
      .catch(err => console.log(err))
  }
  else { //consultar la BD

    Realm.open({ path: './data/spfm.realm', sync:sync, schema: [UsuarioSchema, ReservaSchema, DisponibilidadSchema, InfraestructuraSchema] }).then(DB => {
      let users = DB.objects('Usuario')
      users.forEach(x => console.log(x.nombre))

      /*
      let blog = DB.objectForPrimaryKey('Blog', 'Todo Motos')
      if (blog)
        console.log(blog.title, 'by', blog.creator.name)
      */

      DB.close()
    })
  }

}
