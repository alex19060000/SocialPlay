require('./my-graph.json')
const fs = require('fs')
const ObjectId = require('bson-objectid')



const {
    graphql,
    buildSchema
} = require('graphql')

const model = require('./model') //Database

let DB
model.getDB().then(db => {
    DB = db
})


const sse = require('./utils/notifications') //Notifications
sse.start()


const schema = buildSchema(`
  type Query {
    usuarios: [Usuario]
    reservas: [Reserva]
    infraestructuras: [Infraestructura]
    disponibilidades: [Disponibilidad]
    getInfraActividad(actividad:String!):[Infraestructura]
    getReservasPersona(id_usuario:ID!): [Reserva]
    getReservasEspacio(id_infraestructura:ID!): [Reserva]
    getIdEspacio(nombre_espacio:String!): Int
    getReservasEspacioIntervalo(id_infraestructura:ID!, fecha_ini:String!, fecha_fin:String): [Reserva]
    getDisponibilidadEspacio(id_espacio:ID!): [Disponibilidad]
    usuarioLogin(id_usuario:ID!, pass: String!): String
	jsonld: String
  }


  type Mutation {

    addReserva(id_usuario: ID!
      id_infraestructura: ID!
      estado: String!
      fecha: String!
      hora_ini: String!
      hora_fin: String!
      num_personas: Int!): Boolean,

    addUsuario(id: ID!,nombre: String!,apellidos: String!,
      pass: String!,
      fecha_creacion: String!,
      dni: String!,
      email: String!,
      avatar: String): Boolean


    addInfraestructura(id: ID!,
      nombre: String!,
      ubicacion: String!,
      area_metros: Int!,
      aforo_maximo: Int!,
      actividad: String!): Boolean

    deleteInfraestructura(id: ID!): Boolean

    updateInfraestructura(id: ID!,
      nombre: String!,
      ubicacion: String!,
      area_metros: Int!,
      aforo_maximo: Int!,
      actividad: String!): Boolean

    updateReserva( id: ID!
      id_usuario: ID!
      id_infraestructura: ID!
      estado: String!
      fecha: String!
      hora_ini: String!
      hora_fin: String!
      num_personas: Int!): Boolean

    deleteReserva(id:ID!): Boolean

    addDisponibilidad(id: ID!
      id_infraestructura: ID!
      fecha_ini: String!
      fecha_fin: String!
      hora_ini: String!
      hora_fin: String!
      estacion: String!): Boolean

    updateDisponibilidad(id: ID!
      id_infraestructura: ID!
      fecha_ini: String!
      fecha_fin: String!
      hora_ini: String!
      hora_fin: String!
      estacion: String!): Boolean
  }


  type Usuario{
    _id: ID!
    nombre: String
    apellidos: String
    pass: String
    fecha_creacion: String
    dni: String
    email: String
    avatar: String
  }

  type Reserva{
    _id: ID!
    id_usuario: ID!
    id_infraestructura: ID!
    estado: String
    fecha: String
    hora_ini: String
    hora_fin: String
    num_personas: Int
  }

  type Infraestructura{
    _id: ID!
    nombre: String
    ubicacion: String
    area_metros: Int
    aforo_maximo: Int
    actividad: String
  }

  type Disponibilidad{
    _id: ID!
    id_infraestructura: ID!
    fecha_ini: String
    fecha_fin: String
    hora_ini: String
    hora_fin: String
    estacion: String
  }
`)


const rootValue = {
    /*
       hello : () => "Hello World!",
       users : () => DB.objects('User'),
       blogs:  () => DB.objects('Blog'),
       searchBlog: ({ q }) => {
         q = q.toLowerCase()
         return DB.objects('Blog').filter(x => x.title.toLowerCase().includes(q))
       },
       posts: ({ blogId }) => {
         return DB.objects('Post').filter(x => x.blog.title == blogId)
       },
       addPost: ({title, content, authorId, blogId}) => {

         let blog = DB.objectForPrimaryKey('Blog', blogId)
         let auth = DB.objectForPrimaryKey('User', authorId)
         let data = null
         
         if (blog && auth){
            data = {
                         title: title,
                         content: content,
                         author: auth,
                         blog: blog,
                         timestamp: new String()
                        }

            DB.write( () => { DB.create('Post', data) }) 

            // SSE notification (same view as in graphQL)
            let post = {title: data.title, content: data.content, author: {name: data.author.name}, blog: {title: blog.title}}
            sse.emitter.emit('new-post', post)
         }

         return data
       },
       */


    jsonld: () => {
        fs.readFile('./my-graph.json', 'utf8', (err, data) => {
            if (err) {
                console.error(err)
                return data
            }
            console.log(data)

            return {
                jsonld: data
            }
        })
    },
    usuarios: () => DB.objects('Usuario'),
    infraestructuras: () => DB.objects('Infraestructura'),
    reservas: () => DB.objects('Reserva'),
    disponibilidades: () => DB.objects('Disponibilidad'),
    getInfraActividad: ({
        actividad
    }) => {
        return DB.objects('Infraestructura').filter(infraestructura => infraestructura.actividad == actividad)
    },
    getReservasPersona: ({
        id_usuario
    }) => {
        return DB.objects('Reserva').filter(reserva => reserva.id_usuario == id_usuario)
    },
    getReservasEspacio: ({
        id_infraestructura
    }) => {
        return DB.objects('Reserva').filter(reserva => reserva.id_infraestructura == id_infraestructura)
    },

    getIdEspacio: ({
        nombre_espacio
    }) => {
        return ((DB.objects('Infraestructura').filter(inf => inf.nombre == nombre_espacio)))

    },
    getReservasEspacioIntervalo: ({
        id_infraestructura,
        fecha_ini,
        fecha_fin
    }) => {
        return (DB.objects('Reserva').filter(reserva => reserva.id_infraestructura == id_infraestructura).filter(reserva => reserva.fecha === fecha_ini))
    },
    getDisponibilidadEspacio: ({
        id_espacio
    }) => {
        return DB.objects('Disponibilidad').filter(disponibilidad => disponibilidad.id_infraestructura == id_espacio)
    },
    usuarioLogin: ({
        id_usuario,
        pass
    }) => {
        if (id_usuario == 1 && pass == "pass") { //Ejemplo trivial

            let success = {
                "status": "sucess",
                "operation_date": new Date()
            }
            return JSON.stringify(success);
        }

        let fail = {
            "status": "fail",
            "operation_date": new Date()
        }
        return JSON.stringify(fail);
    },

    addUsuario: ({
        id,
        nombre,
        apellidos,
        pass,
        fecha_creacion,
        dni,
        email,
        avatar
    }) => {

        data = {
            _id: ObjectId(),
            _partition: model.partitionKey,
            nombre: nombre,
            apellidos: apellidos,
            fecha_creacion: fecha_creacion,
            dni: dni,
            avatar: avatar,
            email: email,
            pass: pass
        }

        return DB.write(() => {
            DB.create('Usuario', data)
        })


    },

    addInfraestructura: ({
        id,
        nombre,
        ubicacion,
        area_metros,
        aforo_maximo,
        actividad
    }) => {

        data = {
            _id: ObjectId(),
            _partition: model.partitionKey,
            ubicacion: ubicacion,
            area_metros: area_metros,
            aforo_maximo: aforo_maximo,
            actividad: actividad
        }

        return DB.write(() => {
            DB.create('Infraestructura', data)
        })



    },

    addReserva: ({
        id_usuario,
        id_infraestructura,
        estado,
        fecha,
        hora_ini,
        hora_fin,
        num_personas
    }) => {
        data = {
            _id: ObjectId(),
            _partition: model.partitionKey,
            id_usuario: ObjectId(id_usuario),
            id_infraestructura: ObjectId(id_infraestructura),
            estado: estado,
            fecha: fecha,
            hora_ini: hora_ini,
            hora_fin: hora_fin,
            num_personas: num_personas
        }

        DB.write(() => {
            DB.create('Reserva', data)
        })
        // SSE notification (same view as in graphQL)
        let reserva = {
            _id: data._id,
            id_usuario: data.id_usuario,
            id_infraestructura: data.id_infraestructura,
            estado: data.estado,
            fecha: data.fecha,
            hora_ini: data.hora_ini,
            hora_fin: data.hora_fin,
            num_personas: data.num_personas
        }
        sse.emitter.emit('nueva-reserva', reserva)

    },


    //A la hora de borrar, se debe recuperar en primer lugar el objeto.
    deleteInfraestructura: ({
        id
    }) => {

        return DB.write(() => {

            let x = DB.objectForPrimaryKey("Infraestructura", id)
            DB.delete(x)
        });

    },

    //Las modificaciones también se realizan de forma especial
    updateInfraestructura: ({
        id,
        nombre,
        ubicacion,
        area_metros,
        aforo_maximo,
        actividad
    }) => {

        // Iniciamos una transacción
        return DB.write(() => {
            const inf = DB.objectForPrimaryKey("Infraestructura", ObjectId(id))
            // Cambiamos los campos en tiempo real
            inf.nombre = nombre;
            inf.ubicacion = ubicacion;
            inf.area_metros = area_metros;
            inf.aforo_maximo = aforo_maximo;
            inf.actividad = actividad;

        });


    },

    updateReserva: ({
        id,
        id_infraestructura,
        estado,
        fecha,
        hora_ini,
        hora_fin,
        num_personas
    }) => {
		
		

        // Iniciamos una transacción ==> NO SE PERMITE ACTUALIZAR NI EL "ID" NI EL "ID_USUARIO"
        DB.write(() => {
            const inf = DB.objectForPrimaryKey("Reserva", ObjectId(id))
            // Cambiamos los campos en tiempo real
            inf.id_infraestructura = ObjectId(id_infraestructura);
            inf.estado = "CREADA";
            inf.fecha = fecha;
            inf.hora_ini = hora_ini;
            inf.hora_fin = hora_fin;
            inf.num_personas = num_personas;
            _partition: model.partitionKey;
            // inf._id = ObjectId(id);


        });
        // SSE notification (same view as in graphQL)
        let reserva = {
            _id: id,
            id_infraestructura: id_infraestructura,
            estado: estado,
            fecha: fecha,
            hora_ini: hora_ini,
            hora_fin: hora_fin,
            num_personas: num_personas
        }
        sse.emitter.emit('modificar-reserva', reserva)
	
    },



    deleteReserva: ({
        id
    }) => {


        DB.write(() => {
            let x = DB.objectForPrimaryKey("Reserva", ObjectId(id))
            DB.delete(x)
        });
        // SSE notification (same view as in graphQL)
        let reserva = {
            _id: ObjectId(id)
        }
        sse.emitter.emit('borrar-reserva', reserva)

    },

    addDisponibilidad: ({
        id,
        id_infraestructura,
        fecha_ini,
        fecha_fin,
        hora_ini,
        hora_fin,
        estacion
    }) => {

        data = {
            _id: ObjectId(),
            _partition: model.partitionKey,
            id_infraestructura: id_infraestructura,
            fecha_ini: fecha_ini,
            fecha_fin: fecha_fin,
            hora_ini: hora_ini,
            hora_fin: hora_fin,
            estacion: estacion
        }

        return DB.write(() => {
            DB.create('Disponibilidad', data)
        })
    },

    updateDisponibilidad: ({
        id,
        id_infraestructura,
        fecha_ini,
        fecha_fin,
        hora_ini,
        hora_fin,
        estacion
    }) => {

        // Iniciamos una transacción 
        return DB.write(() => {
            const inf = DB.objectForPrimaryKey("Disponibilidad", id)
            // Cambiamos los campos en tiempo real
            inf.id_infraestructura = id_infraestructura;
            inf.fecha_ini = fecha_ini;
            inf.fecha_fin = fecha_fin;
            inf.hora_ini = hora_ini;
            inf.hora_fin = hora_fin;
            inf.estacion = estacion;

        });
    }


}

exports.root = rootValue
exports.schema = schema
exports.sse = sse